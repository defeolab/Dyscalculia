class AreaData:

    def __init__(self, circle_radius, size_of_chicken, average_space_between, number_of_chickens):
        self.circleRadius = circle_radius
        self.sizeOfChicken = size_of_chicken
        self.averageSpaceBetween = average_space_between
        self.numberOfChickens = number_of_chickens
