DELETE FROM trial_result;
DELETE FROM player;
