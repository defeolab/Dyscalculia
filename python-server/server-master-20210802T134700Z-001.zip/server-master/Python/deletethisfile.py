# -*- coding: utf-8 -*-
"""
Created on Fri Jul 30 22:18:34 2021

@author: vdefe
"""

A = 1.3